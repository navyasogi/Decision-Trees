##Set the working directory 
setwd("/Users/navyasogi/Downloads/census-adult.txt")
dir()
##Read the dataset 
data<-read.csv("census-adult.txt",na.strings="")
#View the data
View(data)

##Name the columns of the dataset
colnames(data) <- c("age", "workclass", "fnlwgt", "education", 
                                         "education_num", "marital_status", "occupation",
                                         "relationship", "race", "sex", "capital_gain",
                                         "capital_loss", "hours_per_week", "native_country", "income")
#Removing the tuples having missing values
data<-read.delim("/Users/navyasogi/Downloads/census-adult.txt",
                                 sep = ",",
                                     header = FALSE,
                                    na.strings = " ?")

data<-na.omit(data)
row.names(data)<-1:nrow(data)
View(data)##returns 30162 rows after cleaning

summary(data)

#used to know the distribution of every feature against income
table (train[,c("age", "income")])
table (train[,c("education_num", "income")])
table (train[,c("capital_gain", "income")])
table (train[,c("capital_loss", "income")])
table (train[,c("hours_per_week", "income")])
table (train[,c("workclass", "income")])
table (train[,c("occupation", "income")])
table (train[,c("marital_status", "income")])
table (train[,c("education", "income")])
table (train[,c("relationship", "income")])
table (train[,c("sex", "income")])
table (train[,c("native_country", "income")])
table (train[,c("race", "income")])
table (train[,c("fnlwgt","income")])


install.packages("ggplot2")
library(ggplot2)
#graphical visualization of the every column
qplot (income, data = train, fill = sex) + facet_grid (. ~ sex)
qplot (income, data = train, fill = education_num) + facet_grid (. ~ education_num)
qplot (income, data = train, fill = capital_gain) + facet_grid (. ~ capital_gain)
qplot (income, data = train, fill = capital_loss) + facet_grid (. ~ capital_loss)
qplot (income, data = train, fill = hours_per_week) + facet_grid (. ~ hours_per_week)
qplot (income, data = train, fill = workclass) + facet_grid (. ~ workclass)
qplot (income, data = train, fill = occupation) + facet_grid (. ~ occupation)
qplot (income, data = train, fill = marital_status) + facet_grid (. ~ marital_status)
qplot (income, data = train, fill = relationship) + facet_grid (. ~ relationship)
qplot (income, data = train, fill = education) + facet_grid (. ~ education)
qplot (income, data = train, fill = native_country) + facet_grid (. ~ native_country)
qplot (income, data = train, fill = age) + facet_grid (. ~ age)
qplot (income, data = train, fill = race) + facet_grid (. ~ race)
qplot (income, data = train, fill = fnlwgt) + facet_grid (. ~ fnlwgt)


#finding the correlation between cotinuous variables
correlation = cor (train[, c("age", "education_num", "capital_gain", "capital_loss", "hours_per_week", "fnlwgt" )])
diag (correlation) = 0 #Remove self correlations
correlation
# Building correplot to visualize the correlartion matrix
install.packages("corrplot")
library(corrplot)
corrplot(cor(correlation), method="number", is.corr=FALSE)

tree <- rpart(income ~ .,
              data = data,
              method = "class")
imp <- varImp(tree)
rownames(imp)[order(imp$Overall, decreasing=TRUE)]

#summarizing every feature
summary (train[ train$income == "<=50K", 
                       c("capital_gain", "capital_loss")])

summary (train[ train$income == ">50K", 
                c("capital_gain", "capital_loss")])

summary (train$education_num)
summary(train$age)
summary(train$sex)
summary(train$race)
summary(train$hours_per_week)
summary(train$fnlwgt)


set.seed(40) # Set Seed so that same sample can be reproduced in future also
#taking a sample of 2000 rows
sample_data<- sample_n(data,2000)
View(sample_data)
# Now Selecting 80% of data as sample from total 'n' rows of the data as train 
sample <- sample.int(n = nrow(sample_data), size = floor(.8*nrow(sample_data)), replace = F)
train <- sample_data[sample, ]
test  <- sample_data[-sample, ]
View(train)
View(test)

summary(train)

colnames(train) <- c("age", "workclass", "fnlwgt", "education", 
                    "education_num", "marital_status", "occupation",
                    "relationship", "race", "sex", "capital_gain",
                    "capital_loss", "hours_per_week", "native_country", "income")

colnames(test) <- c("age", "workclass", "fnlwgt", "education", 
                    "education_num", "marital_status", "occupation",
                    "relationship", "race", "sex", "capital_gain",
                    "capital_loss", "hours_per_week", "native_country", "income")



##set.seed(40)
##sample_data<- sample_n(train,2000)
##View(sample_data)

#Calculating entropy of every attribute
entropy <- function(target) {
  freq <- table(target)/length(target)
  # vectorize
  vec <- as.data.frame(freq)[,2]
  #drop 0 to avoid NaN resulting from log2
  vec<-vec[vec>0]
  #compute entropy
  -sum(vec * log2(vec))
}

entropy(train$marital_status)
entropy(train$workclass)
entropy(train$occupation)
entropy(train$age)
entropy(train$hours_per_week)
entropy(train$relationship)
entropy(train$education_num)
entropy(train$capital_gain)
entropy(train$capital_loss)
entropy(train$native_country)
entropy(train$education)


#Calculating information gain 
install.packages("dplyr")
library(dplyr)
IG_cal<-function(data,target,feature){
  #Strip out rows where feature is NA
  data<-data[!is.na(data[,feature]),] 
  #use dplyr to compute entropy and prob for each value of the feature
  dd_data <- data %>% group_by_at(feature) %>% summarise(e=entropy(get(target)), 
                                                         n=length(get(target))
  )
  
  #compute entropy for the parent
  e0<-entropy(data[,target])
  #calculate prob for each value of feature
  dd_data$p<-dd_data$n/nrow(data)
  #compute IG
  IG<-e0-sum(dd_data$p*dd_data$e)
  
  return(IG)
}


IG_cal(train,"marital_status","income")
IG_cal(train,"occupation","income")
IG_cal(train,"workclass","income")
IG_cal(train,"age","income")
IG_cal(train,"hours_per_week","income")
IG_cal(train,"relationship","income")
IG_cal(train,"education","income")
IG_cal(train,"education_num","income")
IG_cal(train,"capital_gain","income")
IG_cal(train,"capital_loss","income")
IG_cal(train,"native_country","income")
IG_cal(train, "fnlwgt","income")

#Plotting the decision tree using rpart
install.packages("rpart")
install.packages("rpart.plot")
library(rpart)
library(rpart.plot)
#Features selected for the tree
fit <- rpart(income ~  age + education + fnlwgt + relationship + workclass + capital_gain  + hours_per_week + education_num
             + marital_status, data=train)
rpart.plot(fit)
rpart.plot(fit,box.palette = "green") 


printcp(fit)
#predicting using confusion matrix 
install.packages("caret")
library(caret)
install.packages("e1071")
library(e1071)
#test
pred <-predict(fit, test, type = 'class')
t <- table(test$income, pred)
confusionMatrix(t)
#train
pred_train <- predict(fit, train, type = 'class')
t_train <- table(train$income, pred_train)
confusionMatrix(t_train)
#computing error rate
paste0("Error rate = 1 - accuracy = 1 - ", accuracy_test, " = ", round(1 - accuracy_test, 5))

is.na(test)
#Calculating precision, recall and f1 score
accuracy_test <- sum(diag(t)) / sum(t)
precision <- diag(t) / colSums(t)
recall <- diag(t) / rowSums(t)
accuracy_train <- sum(diag(t_train)) / sum(t_train)
print(paste('Accuracy for test', accuracy_test))
print(paste('Precision for test', precision[1:1]))
print(paste('Recall for test', recall[1:1]))
f1 <-   2 * (precision[1:1] * recall[1:1] / (precision[1:1] + recall[1:1]))
print(paste('F1 score for test',f1[1:1]))

precision_train <- diag(t_train) / colSums(t_train)
print(paste('Precision for train', precision_train[1:1]))
recall_train <- diag(t_train) / rowSums(t_train)
print(paste('Recall for train', recall_train[1:1]))
f1_train <-   2 * (precision_train[1:1] * recall_train[1:1] / (precision_train[1:1] + recall_train[1:1]))
print(paste('F1 score for test',f1_train[1:1]))

  
#Computing Gini index
install.packages("reldist")
library(reldist)
Gini(train$age)
Gini(train$workclass)
Gini(train$education)
Gini(train$marital_status)
Gini(train$occupation)
Gini(train$relationship)
Gini(train$race)
Gini(train$sex)
Gini(train$capital_gain)
Gini(train$capital_loss)
Gini(train$hours_per_week)
Gini(train$native_country)
Gini(train$fnlwgt)

gini <- function(x, unbiased = TRUE, na.rm = FALSE){
  if (!is.numeric(x)){
    warning("'x' is not numeric; returning NA")
    return(NA)
  }
  if (!na.rm && any(na.ind <- is.na(x)))
    stop("'x' contain NAs")
  if (na.rm)
    x <- x[!na.ind]
  n <- length(x)
  mu <- mean(x)
  N <- if (unbiased) n * (n - 1) else n * n
  ox <- x[order(x)]
  dsum <- drop(crossprod(2 * 1:n - n - 1,  ox))
  dsum / (mu * N)
}

gini(c(train$age))
gini(c(train$workclass))
gini(c(train$education))
gini(c(train$marital_status))
gini(c(train$occupation))
gini(c(train$relationship))
gini(c(train$capital_gain))
gini(c(train$capital_loss))
gini(c(train$hours_per_week))
gini(c(train$native_country))

#plotting decision tree using gini
gini_fit <- rpart(income ~ age + education + fnlwgt + workclass + occupation + relationship , data=train)
rpart.plot(gini_fit)
rpart.plot(fit,box.palette = "green") 
#predicting using confusion matrix
pred <-predict(gini_fit, test, type = 'class')
t <- table(test$income, pred)
confusionMatrix(t)
#computing precision,recall and f1 score
precision <- diag(t) / colSums(t)
recall <- diag(t) / rowSums(t)
print(paste('Precision for test', precision[1:1]))
print(paste('Recall for test', recall[1:1]))
f1 <-   2 * (precision[1:1] * recall[1:1] / (precision[1:1] + recall[1:1]))
print(paste('F1 score for test',f1[1:1]))

precision_train <- diag(t_train) / colSums(t_train)
print(paste('Precision for train', precision_train[1:1]))
recall_train <- diag(t_train) / rowSums(t_train)
print(paste('Recall for train', recall_train[1:1]))
f1_train <-   2 * (precision_train[1:1] * recall_train[1:1] / (precision_train[1:1] + recall_train[1:1]))
print(paste('F1 score for test',f1_train[1:1]))


#Naive Bayes classification
install.packages("naivebayes")
library(naivebayes)
install.packages("caret")
library(caret)
NB_model <- naiveBayes(income~ ., data=train)
print(NB_model)
plot(NB_model)
printcp(NB_model)
#prediction using confusion matrix
NB_pred <- predict(NB_model, test)
t1 <- table(test$income, NB_pred)
cm <- confusionMatrix(t1)
confusionMatrix(t1)
#visualizing confusion matrix
cm$table
fourfoldplot(cm$table)
plot(cm$table)

NB_pred_train <- predict(NB_model, train)
t2 <- table(train$income, NB_pred_train)
confusionMatrix(t2)
#Computing precision, recall and f1 score
precision_test_NB <- diag(t1) / colSums(t1)
print(paste('Precision for train', precision_test_NB[1:1]))
recall_test_NB<- diag(t1) / rowSums(t1)
print(paste('Recall for train', recall_test_NB[1:1]))
f1_test_NB <-   2 * (precision_test_NB[1:1] * recall_test_NB[1:1] / (precision_test_NB[1:1] + recall_test_NB[1:1]))
print(paste('F1 score for test',f1_test[1:1]))

precision_train_NB <- diag(t2) / colSums(t2)
print(paste('Precision for train', precision_train_NB[1:1]))
recall_train_NB <- diag(t2) / rowSums(t2)
print(paste('Recall for train', recall_train_NB[1:1]))
f1_train_NB <-   2 * (precision_train_NB[1:1] * recall_train_NB[1:1] / (precision_train_NB[1:1] + recall_train_NB[1:1]))
print(paste('F1 score for test',f1_train_NB[1:1]))


install.packages("pROC")
library(pROC)
install.packages("ROCR")
library(ROCR)
pred2 <- prediction(as.numeric(test$pred), as.numeric(test$income))
rocs <- performance(pred2,"tpr","fpr")
plot(rocs, col = as.list(test$pred),main="Test Set ROC Curves")
